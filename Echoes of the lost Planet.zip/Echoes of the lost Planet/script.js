const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const W = canvas.width, H = canvas.height;

const ui = {
  crystals: document.getElementById("crystals"),
  time: document.getElementById("time"),
  health: document.getElementById("health"),
  batteries: document.getElementById("batteries"),
  level: document.getElementById("level"),
  dodge: document.getElementById("dodge"),
  message: document.getElementById("message")
};
const keys = {};
let game, lastTime, timerAccumulator;
let deathTimer=null, toastTimer=null;

const LEVELS = [
  { name:"Arrival", goal:3, time:60, health:3, meteorCount:1, meteorSpeed:90, batteryCount:2, obstacleCount:4, shipPos:{x:850,y:60} },
  { name:"Crystal Canyon", goal:4, time:58, health:3, meteorCount:2, meteorSpeed:120, batteryCount:2, obstacleCount:6, shipPos:{x:850,y:460} },
  { name:"Storm Valley", goal:5, time:55, health:3, meteorCount:3, meteorSpeed:150, batteryCount:2, obstacleCount:8, shipPos:{x:60,y:460} },
  { name:"Ancient Ruins", goal:6, time:52, health:2, meteorCount:4, meteorSpeed:175, batteryCount:2, obstacleCount:10, shipPos:{x:450,y:60} },
  { name:"Core of the Planet", goal:7, time:50, health:2, meteorCount:5, meteorSpeed:205, batteryCount:2, obstacleCount:12, shipPos:{x:850,y:260} }
];

function rectsOverlap(a,b,margin=0){
  return !(a.x+a.w+margin<b.x || b.x+b.w+margin<a.x || a.y+a.h+margin<b.y || b.y+b.h+margin<a.y);
}

function makeItems(count, type, obstacles, shipPos) {
  const items = [];
  for (let i=0;i<count;i++) {
    let x, y, tries=0, ok;
    do {
      x = 80 + Math.random()*(W-160);
      y = 70 + Math.random()*(H-140);
      tries++;
      const nearPlayerSpawn = x < 140 && y > 190 && y < 330;
      const inObstacle = obstacles && obstacles.some(o=>circleRectCollision({x,y,r:22},o));
      const nearShip = shipPos && distance({x,y},shipPos) < 70;
      ok = !nearPlayerSpawn && !inObstacle && !nearShip;
    } while (tries < 150 && !ok);
    items.push({x,y,got:false,type});
  }
  return items;
}

function makeObstacles(count, shipPos) {
  const base = [
    {x:120,y:190,w:170,h:24},{x:350,y:285,w:190,h:24},
    {x:610,y:100,w:25,h:150},{x:700,y:370,w:125,h:24},
    {x:420,y:80,w:24,h:120},{x:180,y:390,w:125,h:24}
  ];
  const obstacles = base.slice(0, Math.min(count, base.length));

  // Levels that need more obstacles than the hand-placed base layout get
  // extra randomly-placed ones, kept clear of the player's start corner,
  // the level's spaceship, and (mostly) each other.
  while (obstacles.length < count) {
    const vertical = Math.random() < 0.5;
    const w = vertical ? 20 + Math.random()*14 : 70 + Math.random()*90;
    const h = vertical ? 70 + Math.random()*90 : 20 + Math.random()*14;
    let x, y, tries = 0, ok;
    do {
      x = 90 + Math.random()*(W-180-w);
      y = 70 + Math.random()*(H-140-h);
      tries++;
      const rect = {x,y,w,h};
      const nearPlayerSpawn = x < 160 && y+h > 170 && y < 350;
      const nearShip = shipPos && Math.abs((x+w/2)-shipPos.x) < 110 && Math.abs((y+h/2)-shipPos.y) < 110;
      const overlapsExisting = obstacles.some(o=>rectsOverlap(rect,o,16));
      ok = !nearPlayerSpawn && !nearShip && !overlapsExisting;
    } while (tries < 150 && !ok);
    obstacles.push({x,y,w,h});
  }
  return obstacles;
}

function makeMeteors(count, speed, level) {
  // Meteors periodically fire a laser bolt at the player; higher levels
  // fire more often and the bolts travel faster.
  const fireInterval = Math.max(1.1, 2.7 - level*0.28);
  return Array.from({length:count}, (_,i) => ({
    x: 180 + Math.random()*(W-250),
    y: 60 + Math.random()*(H-120),
    vx: (i%2 ? -1 : 1) * (speed + Math.random()*45),
    vy: i%3===0 ? (speed*.55) : 0,
    r: 12 + Math.random()*4,
    fireInterval,
    fireCooldown: Math.random()*fireInterval
  }));
}

function newGame() {
  startLevel(1);
}

function startLevel(level) {
  if(deathTimer){clearTimeout(deathTimer);deathTimer=null;}
  if(toastTimer){clearTimeout(toastTimer);toastTimer=null;}
  const cfg = LEVELS[level-1];
  const obstacles = makeObstacles(cfg.obstacleCount, cfg.shipPos);
  game = {
    level,
    cfg,
    state:"explore",
    player:{x:55,y:H/2,r:16,speed:230,invuln:0,facing:{x:1,y:0},dodgeCooldown:0},
    crystals:makeItems(cfg.goal,"crystal",obstacles,cfg.shipPos),
    batteries:makeItems(cfg.batteryCount,"battery",obstacles,cfg.shipPos),
    meteors:makeMeteors(cfg.meteorCount,cfg.meteorSpeed,level),
    lasers:[],
    obstacles,
    shipPos:cfg.shipPos,
    crystalsGot:0,
    batteryCount:0,
    health:cfg.health,
    time:cfg.time,
    puzzle:null,
    escapeUnlocked:false
  };
  timerAccumulator=0;
  hideOverlay();
}

function restartStage(){
  if(!game) return;
  startLevel(game.level);
}

function hideOverlay(){ ui.message.className="overlay hidden"; ui.message.innerHTML=""; }

function showOverlay(html){
  ui.message.className="overlay";
  ui.message.innerHTML=`<div class="overlay-card">${html}</div>`;
}

// A small, non-blocking banner (no button) that the caller auto-dismisses.
function showToast(html){
  ui.message.className="overlay toast";
  ui.message.innerHTML=`<div class="overlay-card toast-card">${html}</div>`;
}

function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y);}

function circleRectCollision(c,r){
  const nx=clamp(c.x,r.x,r.x+r.w), ny=clamp(c.y,r.y,r.y+r.h);
  return Math.hypot(c.x-nx,c.y-ny)<c.r;
}

function blocked(x,y){
  const p={...game.player,x,y};
  return game.obstacles.some(o=>circleRectCollision(p,o));
}

const DODGE_COOLDOWN=2.5;

// A short dash in the player's current (or last-faced) direction, with a
// few brief invulnerability frames. Blocked by obstacles like normal
// movement, and gated by a cooldown so it can't be spammed.
function triggerDodge(){
  if(!game || game.state!=="explore") return;
  const p=game.player;
  if(p.dodgeCooldown>0) return;

  const dx=(keys.ArrowRight||keys.d?1:0)-(keys.ArrowLeft||keys.a?1:0);
  const dy=(keys.ArrowDown||keys.s?1:0)-(keys.ArrowUp||keys.w?1:0);
  const len=Math.hypot(dx,dy);
  const fx=len>0?dx/len:p.facing.x, fy=len>0?dy/len:p.facing.y;
  p.facing={x:fx,y:fy};

  const steps=10, stepDist=30/steps;
  for(let i=0;i<steps;i++){
    const stepX=p.x+fx*stepDist, stepY=p.y+fy*stepDist;
    if(!blocked(stepX,p.y)) p.x=clamp(stepX,18,W-18);
    if(!blocked(p.x,stepY)) p.y=clamp(stepY,18,H-18);
  }

  p.invuln=Math.max(p.invuln,0.45);
  p.dodgeCooldown=DODGE_COOLDOWN;
}

function update(dt){
  if(!game || game.state==="ended") return;

  // Oxygen continues counting down during both exploration AND the puzzle.
  timerAccumulator+=dt;
  if(timerAccumulator>=1){
    const s=Math.floor(timerAccumulator);
    game.time-=s;
    timerAccumulator-=s;
    if(game.time<=0){
      game.time=0;
      endGame(false,"Oxygen depleted. The planet's energy remains unstable.");
      return;
    }
  }

  if(game.state!=="explore") return;

  const dx=(keys.ArrowRight||keys.d?1:0)-(keys.ArrowLeft||keys.a?1:0);
  const dy=(keys.ArrowDown||keys.s?1:0)-(keys.ArrowUp||keys.w?1:0);
  const len=Math.hypot(dx,dy)||1;
  const nx=game.player.x+dx/len*game.player.speed*dt;
  const ny=game.player.y+dy/len*game.player.speed*dt;

  if(dx||dy) game.player.facing={x:dx/len,y:dy/len};

  if(dx&&!blocked(nx,game.player.y)) game.player.x=clamp(nx,18,W-18);
  if(dy&&!blocked(game.player.x,ny)) game.player.y=clamp(ny,18,H-18);

  game.player.invuln=Math.max(0,game.player.invuln-dt);
  game.player.dodgeCooldown=Math.max(0,game.player.dodgeCooldown-dt);

  game.meteors.forEach(m=>{
    m.x+=m.vx*dt; m.y+=m.vy*dt;
    if(m.x<15||m.x>W-15)m.vx*=-1;
    if(m.y<15||m.y>H-15)m.vy*=-1;
    if(game.player.invuln===0&&distance(game.player,m)<game.player.r+m.r){
      game.health--;
      game.player.invuln=1.2;
      game.player.x=55; game.player.y=H/2;
      if(game.health<=0){endGame(false,"Your suit was damaged beyond repair.");return;}
    }

    // Meteors periodically lock on and fire a laser bolt at the player.
    m.fireCooldown-=dt;
    if(m.fireCooldown<=0){
      m.fireCooldown=m.fireInterval;
      const ddx=game.player.x-m.x, ddy=game.player.y-m.y;
      const dlen=Math.hypot(ddx,ddy)||1;
      const laserSpeed=340+game.level*20;
      game.lasers.push({
        x:m.x,y:m.y,
        vx:ddx/dlen*laserSpeed, vy:ddy/dlen*laserSpeed,
        life:2
      });
    }
  });

  if(game.state!=="explore") return;

  game.lasers=game.lasers.filter(l=>{
    l.x+=l.vx*dt; l.y+=l.vy*dt; l.life-=dt;
    if(l.life<=0||l.x<-20||l.x>W+20||l.y<-20||l.y>H+20) return false;
    if(game.player.invuln===0&&distance(game.player,l)<game.player.r+4){
      game.health--;
      game.player.invuln=1.2;
      if(game.health<=0) endGame(false,"Your suit was damaged beyond repair.");
      return false;
    }
    return true;
  });

  game.crystals.forEach(c=>{
    if(!c.got&&distance(game.player,c)<30){c.got=true;game.crystalsGot++;}
  });

  game.batteries.forEach(b=>{
    if(!b.got&&distance(game.player,b)<28){
      b.got=true;game.batteryCount++;game.time=Math.min(game.cfg.time,game.time+10);
    }
  });

  if(game.crystalsGot===game.cfg.goal&&!game.puzzle) startPuzzle();
}

function puzzleLength(){
  return Math.min(10, 3 + game.level);
}

const PUZZLE_COLORS=["BLUE","GREEN","RED","YELLOW"];

function sequencesEqual(a,b){
  return a.length===b.length && a.every((c,i)=>c===b[i]);
}

// Generates a random sequence of the given length. If `previous` is
// provided, keeps re-rolling until the new sequence differs from it,
// so a fresh puzzle after a wrong answer is guaranteed to be different.
function generateSequence(length,previous){
  let sequence;
  do{
    sequence=[];
    for(let i=0;i<length;i++) sequence.push(PUZZLE_COLORS[Math.floor(Math.random()*PUZZLE_COLORS.length)]);
  }while(previous && sequencesEqual(sequence,previous));
  return sequence;
}

function startPuzzle(){
  game.state="puzzle";
  const length=puzzleLength();
  const sequence=generateSequence(length);
  game.puzzle={
    sequence,
    progress:0,
    phase:"memorize",
    startedAt:performance.now(),
    revealDelay:Math.max(900,1200-game.level*60)
  };
  showPuzzle();
}

function showPuzzle(){
  const p=game.puzzle;
  const labels={BLUE:"🔵",GREEN:"🟢",RED:"🔴",YELLOW:"🟡"};
  const display=p.sequence.map(c=>`<span>${labels[c]}</span>`).join(" ");
  showOverlay(`
    <h2>⚡ Level ${game.level}: Power Core</h2>
    <p><b>Memorize the sequence.</b> The puzzle will lock in a moment.</p>
    <div class="sequence">${display}</div>
    <p>Sequence length: <b>${p.sequence.length}</b> &nbsp; | &nbsp; Oxygen keeps running!</p>
    <p id="puzzleStatus">Memorizing...</p>
    <div class="sequence" id="puzzleButtons"></div>
  `);

  setTimeout(()=>{
    if(!game || game.state!=="puzzle" || game.puzzle!==p) return;
    p.phase="input";
    document.getElementById("puzzleStatus").textContent=`Enter the sequence: 0 / ${p.sequence.length}`;
    document.getElementById("puzzleButtons").innerHTML=
      ["BLUE","GREEN","RED","YELLOW"].map(c=>`<button onclick="puzzlePick('${c}')">${labels[c]}</button>`).join("");
  },p.revealDelay);
}

window.puzzlePick=function(color){
  const p=game.puzzle;
  if(game.state!=="puzzle" || p.phase!=="input") return;

  if(color===p.sequence[p.progress]){
    p.progress++;
    document.getElementById("puzzleStatus").textContent=`Correct: ${p.progress} / ${p.sequence.length}`;
    if(p.progress===p.sequence.length){
      p.phase="complete";
      game.state="explore";
      game.escapeUnlocked=true;
      // Reward for solving the Power Core puzzle: +10 seconds of oxygen,
      // capped at the level's starting time (same rule as battery pickups).
      game.time=Math.min(game.cfg.time,game.time+10);
      showToast(`
        <h2>⚡ Power Core Restored!</h2>
        <p>+10s oxygen. Reach 🚀 to complete Level ${game.level}.</p>
      `);
      if(toastTimer) clearTimeout(toastTimer);
      toastTimer=setTimeout(()=>{
        toastTimer=null;
        // Only auto-dismiss if nothing more important has taken over the
        // message area since (e.g. the level was already completed or lost).
        if(game && game.state==="explore" && game.escapeUnlocked && game.puzzle && game.puzzle.phase==="complete"){
          hideOverlay();
        }
      },2400);
    }
  }else{
    // A wrong input scraps the current sequence entirely: a brand new
    // (guaranteed-different) sequence is generated and the puzzle goes
    // back to the memorize phase. Oxygen is NOT restored, and the timer
    // keeps running throughout, so a wrong guess costs real time.
    p.sequence=generateSequence(p.sequence.length,p.sequence);
    p.progress=0;
    p.phase="memorize";
    showPuzzle();
  }
};

function checkEscape(){
  if(game.state!=="explore"||!game.escapeUnlocked)return;
  if(distance(game.player,game.shipPos)<42) completeLevel();
}

function completeLevel(){
  if(game.level<LEVELS.length){
    const next=game.level+1;
    showOverlay(`
      <h2>🌟 Level ${game.level} Complete!</h2>
      <p>You restored this area's energy system.</p>
      <p><b>Next:</b> Level ${next} — ${LEVELS[next-1].name}</p>
      <p>The next level has more hazards and a larger crystal objective.</p>
      <button onclick="startLevel(${next})">Next Level</button>
    `);
    game.state="ended";
  }else{
    endGame(true,"You restored the entire planet and escaped. You are the hero of the Lost Planet!");
  }
}

function endGame(win,text){
  game.state="ended";
  if(win){
    showOverlay(`
      <h2>🚀 Mission Complete!</h2>
      <p>${text}</p>
      <p>Final level: <b>${game.level}/${LEVELS.length}</b></p>
      <button onclick="newGame()">Play Again</button>
    `);
  }else{
    showOverlay(`
      <h2>💀 Mission Failed</h2>
      <p>${text}</p>
      <p>Restarting Level ${game.level}...</p>
    `);
    if(deathTimer) clearTimeout(deathTimer);
    deathTimer=setTimeout(()=>{
      deathTimer=null;
      if(game && game.state==="ended") restartStage();
    },1600);
  }
}

function draw(){
  ctx.clearRect(0,0,W,H);
  ctx.fillStyle="#0d2030";ctx.fillRect(0,0,W,H);
  ctx.strokeStyle="#18364c";
  for(let x=0;x<W;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}
  for(let y=0;y<H;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();}

  game.obstacles.forEach(o=>{
    ctx.fillStyle="#263b4c";ctx.fillRect(o.x,o.y,o.w,o.h);
    ctx.strokeStyle="#547087";ctx.strokeRect(o.x,o.y,o.w,o.h);
  });

  ctx.font="34px sans-serif";ctx.textAlign="center";ctx.fillText("🚀",game.shipPos.x,game.shipPos.y+10);
  if(game.escapeUnlocked){ctx.font="12px system-ui";ctx.fillStyle="#b8e8ff";ctx.fillText("ESCAPE",game.shipPos.x,game.shipPos.y+36);}

  game.crystals.forEach(c=>{if(!c.got){ctx.font="27px sans-serif";ctx.fillText("💎",c.x,c.y+9);}});
  game.batteries.forEach(b=>{if(!b.got){ctx.font="25px sans-serif";ctx.fillText("🔋",b.x,b.y+8);}});

  game.meteors.forEach(m=>{
    ctx.fillStyle="#b36b3d";ctx.beginPath();ctx.arc(m.x,m.y,m.r,0,Math.PI*2);ctx.fill();
    ctx.strokeStyle="#e9b17e";ctx.stroke();
  });

  game.lasers.forEach(l=>{
    const blen=Math.hypot(l.vx,l.vy)||1;
    const tailX=l.x-(l.vx/blen)*16, tailY=l.y-(l.vy/blen)*16;
    ctx.save();
    ctx.shadowColor="#ff5c5c";ctx.shadowBlur=8;
    ctx.strokeStyle="#ff5c5c";ctx.lineWidth=3;ctx.lineCap="round";
    ctx.beginPath();ctx.moveTo(tailX,tailY);ctx.lineTo(l.x,l.y);ctx.stroke();
    ctx.restore();
    ctx.fillStyle="#ffd7d7";ctx.beginPath();ctx.arc(l.x,l.y,2.5,0,Math.PI*2);ctx.fill();
  });

  if(game.player.invuln===0||Math.floor(performance.now()/100)%2===0){
    ctx.font="32px sans-serif";ctx.fillText("🧑‍🚀",game.player.x,game.player.y+10);
  }

  ctx.textAlign="left";ctx.fillStyle="#d8e8f5";ctx.font="14px system-ui";
  ctx.fillText(`LEVEL ${game.level}: ${game.cfg.name}`,15,25);
  ctx.fillText(game.escapeUnlocked?"Reach the 🚀!":`Collect ${game.cfg.goal} crystals`,15,45);
}

function loop(now){
  const dt=Math.min((now-lastTime)/1000,.05);
  lastTime=now;
  update(dt);checkEscape();draw();
  ui.level.textContent=game.level;
  ui.crystals.textContent=`${game.crystalsGot}/${game.cfg.goal}`;
  ui.time.textContent=game.time;
  ui.health.textContent=game.health;
  ui.batteries.textContent=game.batteryCount;
  ui.dodge.textContent=game.player.dodgeCooldown>0?`${game.player.dodgeCooldown.toFixed(1)}s`:"Ready";
  requestAnimationFrame(loop);
}

window.addEventListener("keydown",e=>{
  const k=e.key.length===1?e.key.toLowerCase():e.key;
  keys[k]=true;
  if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"," "].includes(e.key))e.preventDefault();
  if(e.key===" "&&!e.repeat) triggerDodge();
  if((e.key==="r"||e.key==="R")&&!e.repeat) restartStage();
});
window.addEventListener("keyup",e=>{
  const k=e.key.length===1?e.key.toLowerCase():e.key;
  keys[k]=false;
});

document.querySelectorAll(".touch-controls button[data-key]").forEach(btn=>{
  const k=btn.dataset.key;
  const down=e=>{e.preventDefault();keys[k]=true;};
  const up=e=>{e.preventDefault();keys[k]=false;};
  btn.addEventListener("pointerdown",down);
  btn.addEventListener("pointerup",up);
  btn.addEventListener("pointercancel",up);
  btn.addEventListener("pointerleave",up);
});

document.getElementById("dodgeBtn").addEventListener("pointerdown",e=>{e.preventDefault();triggerDodge();});

let started=false;

function ensureLoopRunning(){
  if(started) return;
  started=true;
  lastTime=performance.now();
  requestAnimationFrame(loop);
}

function startGame(){
  newGame();
  ensureLoopRunning();
}

document.getElementById("restartTop").addEventListener("click",()=>{ newGame(); ensureLoopRunning(); });

// Don't start playing automatically — show a start screen with a Play
// button, and only spin up the game/loop once the player presses it.
showOverlay(`
  <h2 class="pixel-font pixel-title">🪐 ECHOES OF THE LOST PLANET</h2>
  
  <div class="play-btn-wrap">
    <button class="play-btn pixel-font" onclick="startGame()" aria-label="Play">▶</button>
    <span class="play-tooltip pixel-font">PLAY</span>
  </div>
`);
